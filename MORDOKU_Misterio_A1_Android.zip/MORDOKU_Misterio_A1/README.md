# MORDOKU Misterio A1 — Android
Juego educativo de deducción lógica. Las pistas aparecen primero en euskera y cada una tiene un botón para mostrar la traducción castellana.

## Generar APK
1. Instala Android Studio en un ordenador.
2. Descomprime este ZIP y abre la carpeta del proyecto.
3. Espera a la sincronización de Gradle e instala Android SDK Platform 35 si se solicita.
4. Selecciona **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. El APK estará en `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: Android Studio reciente, JDK 17 y Android SDK Platform 35.

Este ZIP contiene el proyecto fuente listo para compilar, no un APK ya compilado.
