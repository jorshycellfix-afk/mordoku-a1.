# MORDOKU Misterio A1 — Android 2.0

## Novedades de la versión 2.0
- 10 misterios con dificultad progresiva.
- Las traducciones al castellano empiezan ocultas.
- Cada pista tiene su propio botón «Ver traducción / Ocultar traducción».
- Los niveles se desbloquean al completar el misterio anterior.
- El progreso se conserva en el dispositivo.
- Corrección de visualización: las traducciones ocultas ya no aparecen por debajo de las pistas.

## Generar APK
Este ZIP contiene el proyecto fuente Android, no una APK ya compilada.
1. Descomprime el archivo.
2. Abre la carpeta `MORDOKU_Misterio_A1` con Android Studio.
3. Espera la sincronización de Gradle.
4. Ejecuta **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Para generar la APK desde el móvil, puedes subir este ZIP a tu repositorio GitHub y ejecutar el flujo de GitHub Actions que ya configuraste.

Versión: 2.0 · versionCode 3
